import { createClient } from "npm:@supabase/supabase-js@2";

const url = Deno.env.get("SUPABASE_URL")!;

const publishableKey = JSON.parse(
  Deno.env.get("SUPABASE_PUBLISHABLE_KEYS")!
)["default"];

const secretKey = JSON.parse(
  Deno.env.get("SUPABASE_SECRET_KEYS")!
)["default"];

// Cliente exclusivo para operaciones internas
const admin = createClient(url, secretKey, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "apikey, authorization, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Cache-Control": "no-store",
};

function responder(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers,
  });
}

function credencialesInvalidas() {
  return responder(
    { error: "Usuario o contraseña incorrectos" },
    401
  );
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers });
  }

  if (req.method !== "POST") {
    return responder(
      { error: "Metodo no permitido" },
      405
    );
  }

  // Exigir la clave publica del proyecto
  if (req.headers.get("apikey") !== publishableKey) {
    return responder({ error: "Acceso no autorizado" }, 401);
  }

  try {
    // Limitar el tamaño de la solicitud
    const raw = await req.text();

    if (raw.length > 2048) {
      return responder({ error: "Solicitud invalida" }, 400);
    }

    const body = JSON.parse(raw);
    const usuario = body?.usuario;
    const password = body?.password;

    if (
      typeof usuario !== "string" ||
      typeof password !== "string" ||
      password.length < 12 ||
      password.length > 256
    ) {
      return credencialesInvalidas();
    }

    const nombre = usuario.trim().toLowerCase();

    if (!/^[a-z0-9_]{3,30}$/.test(nombre)) {
      return credencialesInvalidas();
    }

    // Buscar identidad interna del trabajador
    const { data: perfil, error: perfilError } =
      await admin
        .from("perfiles")
        .select("id, correo_acceso, rol")
        .eq("usuario", nombre)
        .maybeSingle();

    if (perfilError) {
      console.error("Error consultando perfiles:", {
        codigo: perfilError.code,
        mensaje: perfilError.message,
      });

      return responder(
        { error: "Servicio no disponible" },
         503
      );
    }


    if (!perfil?.correo_acceso) {
      return credencialesInvalidas();
    }

    // Cliente de autenticacion independiente
    // para cada solicitud
    const authClient = createClient(url, publishableKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    // Verificar contraseña mediante Supabase Auth
    const { data, error } =
      await authClient.auth.signInWithPassword({
        email: perfil.correo_acceso,
        password,
      });

    if (error || !data.session || !data.user) {
      return credencialesInvalidas();
    }

    // Confirmar identidad y rol
    if (
      data.user.id !== perfil.id ||
      !["mesera", "administrador"].includes(perfil.rol)
    ) {
      return credencialesInvalidas();
    }

    // Devolver la sesion autenticada
    return responder({
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      expires_in: data.session.expires_in,
      token_type: data.session.token_type,
    });

  } catch {
    return responder(
      { error: "Solicitud invalida" },
      400
    );
  }
});
